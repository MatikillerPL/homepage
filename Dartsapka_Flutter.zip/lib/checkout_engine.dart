import 'models.dart';
const preferredDoubles=[20,16,10,8,12,6,4,2,25];
const preferredSingles=[20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1];

CheckoutSuggestion? getCheckout(int points,int dartsLeft){
  if(points<=1||points>170) return null;
  if(dartsLeft==1){
    if(points%2==0 && points<=40) return CheckoutSuggestion(path:['D${points~/2}'],fallback:['S${points~/2}','MISS']);
    if(points==50) return CheckoutSuggestion(path:['D25'],fallback:['S25','MISS']);
    return null;
  }
  for(final d in preferredDoubles){
    final remain=points-d*2;
    if(remain<=0) continue;
    if(dartsLeft==2 && remain<=20) return CheckoutSuggestion(path:['S$remain','D$d'],fallback:['D$d ❌ → S$d','S$remain ❌ → D$d']);
    if(dartsLeft==3){
      for(final s1 in preferredSingles){
        final s2=remain-s1;
        if(s2>=1 && s2<=20) return CheckoutSuggestion(path:['S$s1','S$s2','D$d'],fallback:['D$d ❌ → S$d','S$s1 ❌ → MISS']);
      }
    }
  }
  return null;
}