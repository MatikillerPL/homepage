enum HitType { single, double, triple, miss }
class Player {
  final String name;
  int points;
  Player(this.name, {this.points = 501});
}
class DartHit {
  final HitType type;
  final int value;
  DartHit(this.type, this.value);
  int get score => type==HitType.single?value:type==HitType.double?value*2:type==HitType.triple?value*3:0;
}
class CheckoutSuggestion {
  final List<String> path;
  final List<String> fallback;
  CheckoutSuggestion({required this.path, required this.fallback});
}