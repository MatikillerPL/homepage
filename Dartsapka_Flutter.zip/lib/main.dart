import 'package:flutter/material.dart';
import 'game_screen.dart';

void main()=>runApp(const DartApp());
class DartApp extends StatelessWidget{
  const DartApp({super.key});
  @override
  Widget build(BuildContext context){
    return MaterialApp(
      debugShowCheckedModeBanner:false,
      theme:ThemeData.dark(),
      home:const GameScreen(),
    );
  }
}