import 'package:flutter/material.dart';
import 'models.dart';
import 'checkout_engine.dart';

class GameScreen extends StatefulWidget{
  const GameScreen({super.key});
  @override
  State<GameScreen> createState()=>_GameScreenState();
}

class _GameScreenState extends State<GameScreen>{
  final players=[Player('Gracz 1'),Player('Gracz 2')];
  int current=0,dartsLeft=3;

  void nextTurn(){setState(()=>{dartsLeft=3,current=(current+1)%players.length});}
  void processHit(DartHit hit){
    setState((){
      final p=players[current];
      p.points-=hit.score;
      dartsLeft--;
      if(dartsLeft==0||p.points<=0) nextTurn();
    });
  }

  @override
  Widget build(BuildContext context){
    final p=players[current];
    final checkout=getCheckout(p.points,dartsLeft);
    List<String> hits=[];
    for(int i=1;i<=20;i++) hits.addAll(['S$i','D$i','T$i']);
    hits.addAll(['S25','D25']);
    return Scaffold(
      appBar:AppBar(title:const Text('🎯 Dartsapka')),
      body:Padding(
        padding:const EdgeInsets.all(8),
        child:Column(
          crossAxisAlignment:CrossAxisAlignment.start,
          children:[
            Text('${p.name} – ${p.points} pkt',style:const TextStyle(fontSize:22)),
            const SizedBox(height:10),
            if(checkout!=null)...[
              const Text('Najlepsze rzuty:',style:TextStyle(fontSize:18,color:Colors.green)),
              Text(checkout.path.join(' → '),style:const TextStyle(fontSize:20,color:Colors.green)),
              const SizedBox(height:8),
              const Text('Jeśli spudłujesz:',style:TextStyle(fontSize:16,color:Colors.orange)),
              for(final f in checkout.fallback) Text('• $f')
            ],
            const SizedBox(height:20),
            Expanded(
              child:GridView.count(
                crossAxisCount:5,
                mainAxisSpacing:4,crossAxisSpacing:4,
                children:hits.map((h)=>ElevatedButton(
                  onPressed:()=>processHit(
                    h.startsWith('S')?DartHit(HitType.single,int.parse(h.substring(1))):
                    h.startsWith('D')?DartHit(HitType.double,int.parse(h.substring(1))):
                    DartHit(HitType.triple,int.parse(h.substring(1)))
                  ),
                  child:Text(h),
                )).toList(),
              ),
            ),
            ElevatedButton(onPressed:nextTurn,child:const Text('Bust / koniec kolejki'))
          ],
        ),
      ),
    );
  }
}